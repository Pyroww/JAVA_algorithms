package br.com.comercio.modelo;

public interface Descontavel {
    double aplicarDesconto(double valorOriginal);
}